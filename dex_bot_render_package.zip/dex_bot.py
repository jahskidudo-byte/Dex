import requests
import time
from telegram import Bot, ParseMode

# === CONFIGURATION ===
BOT_TOKEN = "8390811635:AAG6isJ1paGtgiH7h0Ce26uVIzSX0-_icT8"
CHANNEL_ID = "-1002584198399"
POST_INTERVAL = 60  # seconds
DEXSCREENER_API = "https://api.dexscreener.com/latest/dex/pairs"

# === INITIALIZE TELEGRAM BOT ===
bot = Bot(token=BOT_TOKEN)

# Track posted tokens to avoid duplicates
posted_tokens = set()

def format_token_message(token):
    name = token.get("baseToken", {}).get("name", "N/A")
    symbol = token.get("baseToken", {}).get("symbol", "N/A")
    chain = token.get("chainId", "N/A")
    pair_address = token.get("pairAddress", "N/A")
    ca = token.get("baseToken", {}).get("address", "N/A")

    age = token.get("age", "N/A")
    mc = token.get("fdv", 0) / 1000
    liq = token.get("liquidity", {}).get("usd", 0)
    volume = token.get("volume", {}).get("h24", 0)
    price_change = token.get("priceChange", {}).get("h24", 0)

    socials = token.get("socials", {})
    twitter = socials.get("twitter", "")
    telegram = socials.get("telegram", "")

    chart_link = f"https://dexscreener.com/{chain}/{pair_address}"

    message = f"""⚡ 10 Token Boosts!
{name} – ${symbol}

CA:
<code>{ca}</code>

🌱 Age: {age} | 💰 MC: ${mc:,.2f}k | 💧 Liq: ${liq:,.2f}
📉 24h: {price_change:.2f}% | Vol: ${volume:,.2f}

📊 <a href="{chart_link}">Chart</a> {'| <a href="'+twitter+'">Twitter</a>' if twitter else ''} {'| <a href="'+telegram+'">Telegram</a>' if telegram else ''}
"""
    return message

def fetch_tokens():
    try:
        response = requests.get(DEXSCREENER_API)
        data = response.json()
        return data.get("pairs", [])
    except Exception as e:
        print("API Error:", e)
        return []

def main():
    while True:
        print("Checking for new tokens...")
        tokens = fetch_tokens()
        for token in tokens:
            pair_id = token.get("pairAddress")
            if pair_id and pair_id not in posted_tokens:
                msg = format_token_message(token)
                try:
                    bot.send_message(chat_id=CHANNEL_ID, text=msg, parse_mode=ParseMode.HTML, disable_web_page_preview=True)
                    posted_tokens.add(pair_id)
                    print(f"Posted: {token.get('baseToken', {}).get('symbol')}")
                except Exception as e:
                    print("Failed to post:", e)
        time.sleep(POST_INTERVAL)

if __name__ == "__main__":
    main()
